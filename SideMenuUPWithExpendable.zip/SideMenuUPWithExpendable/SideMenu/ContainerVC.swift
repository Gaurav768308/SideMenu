//
//  ViewController.swift
//  SideMenu
//
//  Created by gaurav on 19/12/18.
//  Copyright © 2018 ELGroup. All rights reserved.
//

import UIKit

class ContainerVC: UIViewController {
    @IBOutlet weak var viewSideMenu: UIView!
    @IBOutlet weak var leadingConstraints: NSLayoutConstraint!
    var sideMenuOpen = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewSideMenu.layer.shadowOpacity = 1
        viewSideMenu.layer.shadowRadius = 6
        
        NotificationCenter.default.addObserver(self, selector: #selector(toggleSideMenu), name: NSNotification.Name("ToggleSideMenu"), object: nil)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(ppXX), name: NSNotification.Name("ppXX"), object: nil)
    }
    
    @objc func toggleSideMenu(){
        if sideMenuOpen {
            sideMenuOpen = false
            leadingConstraints.constant = -240
        }else{
            sideMenuOpen = true
            leadingConstraints.constant = 0
        }
        
        UIView.animate(withDuration: 0.3){
            self.view.layoutIfNeeded()
        }
    }
    
    
    @objc func ppXX() {
        print("call the ppXX22")
    }
    
}

