//
//  ExpendableNames.swift
//  SideMenu
//
//  Created by gaurav on 07/01/19.
//  Copyright © 2019 ELGroup. All rights reserved.
//

import Foundation

struct ExpendableNames {
    var isExpanded: Bool
    let names: [String]
}
