//
//  SettingViewController.swift
//  SideMenu
//
//  Created by gaurav on 19/12/18.
//  Copyright © 2018 ELGroup. All rights reserved.
//

import UIKit

class SettingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
         self.navigationController?.isNavigationBarHidden = true
    }
    

    @IBAction func menu(_ sender: Any) {
        NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }
    

}
