//
//  mainVC.swift
//  SideMenu
//
//  Created by gaurav on 19/12/18.
//  Copyright © 2018 ELGroup. All rights reserved.
//

import UIKit

class mainVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
         NotificationCenter.default.addObserver(self, selector: #selector(showProfile), name: NSNotification.Name("showProfile"), object: nil)
        
         NotificationCenter.default.addObserver(self, selector: #selector(showSetting), name: NSNotification.Name("showSetting"), object: nil)
        
         NotificationCenter.default.addObserver(self, selector: #selector(showSignIn), name: NSNotification.Name("showSignIn"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(ppXX), name: NSNotification.Name("ppXX"), object: nil)

    }

    @objc func showProfile() {
        performSegue(withIdentifier: "showProfile", sender: nil)
    }
    
    @objc func showSetting() {
        performSegue(withIdentifier: "showSetting", sender: nil)
    }
    
    @objc func showSignIn() {
        performSegue(withIdentifier: "showSignIn", sender: nil)
    }
    
    @objc func ppXX() {
        print("call the ppXX")
    }
    

    @IBAction func onMoreTapped(_ sender: Any) {
         print("toggel side menu")
         NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }
}
