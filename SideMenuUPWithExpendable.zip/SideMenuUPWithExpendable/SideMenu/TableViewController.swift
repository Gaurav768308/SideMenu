//
//  TableViewController.swift
//  SideMenu
//
//  Created by gaurav on 07/01/19.
//  Copyright © 2019 ELGroup. All rights reserved.
//

import UIKit

class TableViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    
    var twoDimensionalArray = [ExpendableNames(isExpanded: true, names:[]),
        ExpendableNames(isExpanded: true, names:[]),
        ExpendableNames(isExpanded: true, names:["A2","B2","C2"]),
        ExpendableNames(isExpanded: true, names:["A3","B3"])
    ]
    
    var  showIndexPaths = false
    
    @objc func handeleShowIndexPath(){
        
        var indexPathsToRload = [IndexPath]()
        
        for section in twoDimensionalArray.indices{
            for row in twoDimensionalArray[section].names.indices{
                print(section, row)
                let indexPath = IndexPath(row: row, section: section)
                indexPathsToRload.append(indexPath)
                
            }
            
        }
   
    }
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.sectionHeaderHeight = 50
    }
}



//MARK: - Table View Methods -


extension TableViewController: UITableViewDataSource, UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return  twoDimensionalArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if twoDimensionalArray[section].isExpanded{
            return 0
        }
        
        return twoDimensionalArray[section].names.count
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    
 
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CosmeticsCell") as! CosmeticsCell
        
        let name = twoDimensionalArray[indexPath.section].names[indexPath.row]
        cell.labelName.text = name
        
        tableView.backgroundColor = UIColor.gray
        

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        
        NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
        
        switch indexPath.row {
        case 0: NotificationCenter.default.post(name: NSNotification.Name("showProfile"), object: nil)
        case 1:NotificationCenter.default.post(name: NSNotification.Name("showSetting"), object: nil)
        case 2:NotificationCenter.default.post(name: NSNotification.Name("showSignIn"), object: nil)
        default:
            break
        }
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        
        
        let view12 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        view12.backgroundColor = UIColor.gray

        
        let imgView = UIImageView(frame: CGRect(x: 15, y: 15, width: 25, height: 25))
        imgView.backgroundColor = UIColor.black
        
        
        let button = UIButton(frame: CGRect(x: 40, y: 0, width: 100, height: 50))
        button.setTitle("Close", for: .normal)

        view12.addSubview(imgView)
        view12.addSubview(button)
        

        button.addTarget(self, action:#selector(handelExpendClose), for: .touchUpInside)

        button.tag = section

        return view12
        
    }
    
    
    @objc func handelExpendClose(button: UIButton){
        
        print("trying to expend and close")
        let section = button.tag
        
        if button.tag == 2 {
            var indexPaths = [IndexPath]()
            for row in twoDimensionalArray[section].names.indices{
                print(0, row)
                let indexPath = IndexPath(row: row, section: section)
                indexPaths.append(indexPath)
            }
            
            let isExpanped = twoDimensionalArray[section].isExpanded
            twoDimensionalArray[section].isExpanded = !isExpanped
            
            if isExpanped {
                tableView.insertRows(at: indexPaths, with: .fade)
            }else{
                
                tableView.deleteRows(at: indexPaths, with: .fade)
                
            }
        }else{
  
            if button.tag == 0{
                
                NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
                
                NotificationCenter.default.post(name: NSNotification.Name("showSignIn"), object: nil)
            }
            
        }
    }
}


//MARK: - Table View  Cell Methods -

class CosmeticsCell: UITableViewCell {
    

    @IBOutlet weak var labelName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
